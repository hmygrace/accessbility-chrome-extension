This directory contains example HTML sites to test the local bookmarklet.  Use the bookmarklet from bookmarklet_local.html on any of the pages in this directory.

These sites are included for testing purposes only, since a local copy can be useful for rapid debugging.
