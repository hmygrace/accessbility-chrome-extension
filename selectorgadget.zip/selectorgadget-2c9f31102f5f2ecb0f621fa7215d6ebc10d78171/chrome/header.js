// This file is prepended to build/selectorgadget_combined.js to generate the final contentScript.

(function() {
  if (typeof SelectorGadget == 'undefined') {
